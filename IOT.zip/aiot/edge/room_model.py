"""Physics-inspired room simulator (CO2 mass balance) + fault injection.
Lets the whole system be demonstrated and evaluated without hardware, and
is statistically similar to what an MQ-135 / DHT22 / PIR node would see."""
import numpy as np

OUTDOOR_CO2 = 400.0
GEN_PER_PERSON = 0.5      # ppm / min / person
BASE_VENT = 0.020         # air-change fraction per minute (closed room)
FAN_VENT = 0.060          # with the actuator (fan) switched on
FAULTS = ("spike", "stuck", "drift", "dropout")


class RoomModel:
    def __init__(self, device_id, capacity, seed, kind="classroom"):
        self.id, self.cap, self.kind = device_id, capacity, kind
        self.rng = np.random.default_rng(seed)
        self.co2, self.fan = OUTDOOR_CO2 + 20, False
        self.window_open_until = -1
        self.temp = 23.0
        self.fault, self.fault_left, self.fault_total = None, 0, 0
        self.fault_val, self.drift_rate = None, 0.0

    # ---- occupancy schedule: lecture blocks on weekdays, light use at weekends -----
    def occupancy(self, t_min):
        day, minute = (t_min // 1440) % 7, t_min % 1440
        hour = minute / 60
        if day >= 5:                                  # weekend
            lam = 0.03 * self.cap if 10 <= hour < 14 and self.kind == "lab" else 0.0
        elif self.kind == "hall":                     # corridor: peaks at class changes
            lam = self.cap * (0.35 if (int(hour * 60) % 60) < 10 and 8 <= hour < 18 else 0.05)
        else:
            blocks = [(9, 10), (10.25, 11.25), (11.5, 12.5), (14, 15), (15.25, 16.25)]
            on = any(a <= hour < b for a, b in blocks)
            lam = self.cap * (0.85 if on else 0.05 if 8 <= hour < 18 else 0.0)
        return int(np.clip(self.rng.normal(lam, 1.0 + 0.08 * lam), 0, self.cap)) if lam > 0 else 0

    def step(self, t_min):
        occ = self.occupancy(t_min)
        if self.window_open_until < t_min and self.rng.random() < 0.0015:
            self.window_open_until = t_min + int(self.rng.integers(10, 30))
        vent = FAN_VENT if self.fan else BASE_VENT
        if self.window_open_until >= t_min: vent += 0.03
        self.co2 += GEN_PER_PERSON * occ - vent * (self.co2 - OUTDOOR_CO2) + self.rng.normal(0, 2)
        self.co2 = max(self.co2, OUTDOOR_CO2 - 10)
        hour = (t_min % 1440) / 60
        target = 21.5 + 1.5 * np.sin((hour - 9) / 24 * 2 * np.pi) + 0.05 * occ
        self.temp += 0.1 * (target - self.temp) + self.rng.normal(0, 0.03)
        hum = 48 - 0.9 * (self.temp - 22) + 0.04 * occ + self.rng.normal(0, 0.6)
        return occ, hum

    # ------------------------- sensors + faults -------------------------------------
    def sense(self, occ, hum, fault_rate=0.0006):
        """Returns noisy sensor values (what the MCU reads) and the ground-truth fault label."""
        gas = self.co2 + self.rng.normal(0, 10)
        temp, h = self.temp + self.rng.normal(0, 0.1), hum
        if self.fault is None and fault_rate and self.rng.random() < fault_rate:
            self.fault = FAULTS[int(self.rng.integers(len(FAULTS)))]
            self.fault_left = {"spike": int(self.rng.integers(1, 4)), "stuck": 25,
                               "drift": 60, "dropout": int(self.rng.integers(3, 8))}[self.fault]
            self.fault_total, self.fault_val = self.fault_left, gas
            self.drift_rate = float(self.rng.uniform(8, 14))
        label = 0
        if self.fault:
            label = FAULTS.index(self.fault) + 1
            k = self.fault_total - self.fault_left
            if self.fault == "spike": gas += float(self.rng.uniform(700, 1500))
            elif self.fault == "stuck": gas, temp = self.fault_val, self.temp
            elif self.fault == "drift": gas += self.drift_rate * (k + 1)
            elif self.fault == "dropout": temp, h = -999.0, -1.0
            self.fault_left -= 1
            if self.fault_left <= 0: self.fault = None
        return gas, temp, h, label
