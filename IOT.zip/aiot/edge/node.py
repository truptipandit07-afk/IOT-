"""Edge node = what runs on the ESP32 (mirrored in edge/esp32_firmware.ino):
sample -> validate -> local differential privacy -> AES-GCM seal -> publish over TLS-MQTT.
Raw occupancy never leaves the device; only an eps-DP noisy count is transmitted."""
import json, time
import numpy as np
from common import config as C
from common.security import derive_device_key, encrypt_reading, dp_count, DeviceVerifier, AuthError, ReplayError
from edge.room_model import RoomModel

T0 = 1_760_000_000  # virtual epoch start (Mon 00:00-aligned for readable plots)


class EdgeNode:
    def __init__(self, device_id, transport, room: RoomModel, epsilon=C.DP_EPSILON,
                 master=C.MASTER_SECRET, seed=0, fault_rate=0.0006):
        self.id, self.t, self.room, self.eps = device_id, transport, room, epsilon
        self.key = derive_device_key(master, device_id)       # provisioned secret
        self.cmd_verifier = DeviceVerifier(self.key, "cmd:" + device_id)
        self.seq, self.rng, self.fault_rate = 0, np.random.default_rng(seed), fault_rate
        self.last_label = 0
        transport.subscribe(C.cmd_topic(device_id), self._on_cmd)

    def _on_cmd(self, topic, payload):
        try:
            cmd = self.cmd_verifier.open(payload)
            self.room.fan = bool(cmd["fan"])                  # actuator (relay) control
        except (AuthError, ReplayError):
            pass                                              # forged/replayed command ignored

    def tick(self, t_min: int):
        occ, hum = self.room.step(t_min)
        gas, temp, h, self.last_label = self.room.sense(occ, hum, self.fault_rate)
        reading = {"ts": T0 + t_min * 60, "temp_c": round(temp, 2), "hum_pct": round(h, 1),
                   "gas_ppm": round(gas, 1), "occ_dp": dp_count(occ, self.eps, C.OCC_SENSITIVITY, self.rng),
                   "fan": int(self.room.fan)}
        self.seq += 1
        self.t.publish(C.data_topic(self.id), encrypt_reading(reading, self.key, self.id, self.seq))
        return reading


def build_fleet(transport, epsilon=C.DP_EPSILON, seed=7, fault_rate=0.0006):
    spec = {"room_A101": (60, "classroom"), "room_A102": (40, "classroom"), "room_B201": (50, "classroom"),
            "lab_C301": (30, "lab"), "hall_D001": (80, "hall")}
    return [EdgeNode(d, transport, RoomModel(d, cap, seed + i, kind), epsilon, seed=seed + 100 + i,
                     fault_rate=fault_rate) for i, (d, (cap, kind)) in enumerate(spec.items())]
