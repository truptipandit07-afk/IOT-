"""Fleet simulator CLI + offline dataset generator.
  python -m edge.simulator --mode mqtt --days 1 --interval 0.05    # publish over mutual-TLS MQTT
"""
import argparse, time
import numpy as np, pandas as pd
from common import config as C
from common.transport import MqttTransport, LoopbackTransport
from edge.node import build_fleet, EdgeNode, T0
from edge.room_model import RoomModel
from edge import node as _n


def generate_dataset(days=10, seed=1, fault_rate=0.0006) -> pd.DataFrame:
    """Ground-truth labelled dataset (includes true occupancy + fault labels: LAB USE ONLY)."""
    rows = []
    spec = [("room_A101", 60, "classroom"), ("room_A102", 40, "classroom"), ("room_B201", 50, "classroom"),
            ("lab_C301", 30, "lab"), ("hall_D001", 80, "hall")]
    for i, (d, cap, kind) in enumerate(spec):
        r = RoomModel(d, cap, seed * 1000 + i, kind)
        for t in range(days * 1440):
            occ, hum = r.step(t)
            gas, temp, h, lab = r.sense(occ, hum, fault_rate)
            rows.append((d, t, T0 + t * 60, temp, h, gas, occ, r.co2, int(lab > 0), lab))
    return pd.DataFrame(rows, columns=["device", "t_min", "ts", "temp_c", "hum_pct", "gas_ppm",
                                       "occ_true", "co2_true", "fault", "fault_type"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["mqtt", "loopback"], default="mqtt")
    ap.add_argument("--days", type=float, default=1)
    ap.add_argument("--interval", type=float, default=0.05, help="wall-clock seconds per simulated minute")
    ap.add_argument("--epsilon", type=float, default=C.DP_EPSILON)
    a = ap.parse_args()
    fleet = []
    if a.mode == "mqtt":
        # one authenticated TLS connection per device (client cert CN == device id)
        for node in build_fleet(LoopbackTransport(), a.epsilon):
            tr = MqttTransport(node.id); node.t = tr
            tr.subscribe(C.cmd_topic(node.id), node._on_cmd); tr.start(); fleet.append(node)
    for t in range(int(a.days * 1440)):
        for n in fleet: n.tick(t)
        time.sleep(a.interval)
    for n in fleet: n.t.stop()


if __name__ == "__main__":
    main()
