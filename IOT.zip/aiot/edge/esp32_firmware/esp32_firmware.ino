/*
 * Privacy-aware AIoT edge node (ESP32) - mirrors edge/node.py
 * Sensors : DHT22 (GPIO4), MQ-135 (ADC GPIO34), PIR (GPIO27), Relay/fan (GPIO26)
 * Security: mutual-TLS MQTT (port 8883), AES-256-GCM payload encryption with per-device key,
 *           monotonic sequence counter (replay protection), local differential privacy on occupancy.
 * Libraries: PubSubClient, DHT sensor library, WiFi, mbedTLS (bundled with ESP32 core), ArduinoJson.
 * Provision : python -m scripts.provision_device room_A101  -> paste output into secrets.h
 *             put ca.crt / room_A101.crt / room_A101.key text into the *_PEM strings in secrets.h
 * NOTE: hardware-untested reference implementation - the Python simulator exercises the identical protocol.
 */
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <ArduinoJson.h>
#include <time.h>
#include "mbedtls/gcm.h"
#include "mbedtls/base64.h"
#include "secrets.h"   // WIFI_SSID, WIFI_PASS, BROKER_HOST, DEVICE_ID, DEVICE_KEY_HEX, CA_PEM, CLIENT_CRT_PEM, CLIENT_KEY_PEM

#define DHTPIN 4
#define MQ_PIN 34
#define PIR_PIN 27
#define FAN_PIN 26
const float EPSILON = 1.0f;            // local DP budget per report
const uint32_t PERIOD_MS = 60000;      // 1 report per minute; 10 s sampling inside the window
DHT dht(DHTPIN, DHT22);
WiFiClientSecure net; PubSubClient mqtt(net);
uint8_t key[32]; uint32_t seq = 0, cmdSeq = 0; int motionEvents = 0; unsigned long lastRep = 0;

void hex2bin(const char *h, uint8_t *o, size_t n) { for (size_t i = 0; i < n; i++) { char b[3] = {h[2*i], h[2*i+1], 0}; o[i] = strtol(b, NULL, 16); } }

float laplace(float scale) {           // inverse-CDF Laplace sample from hardware RNG
  float u = ((float)esp_random() / 4294967296.0f) - 0.5f;
  return -scale * (u < 0 ? -1 : 1) * logf(1.0f - 2.0f * fabsf(u));
}
float mqToPpm(int adc) { float v = adc * 3.3f / 4095.0f; return 400.0f + 2200.0f * powf(v / 3.3f, 2.2f); } // replace with your calibration curve

bool seal(const char *plain, size_t len, char *out, size_t outLen) {   // writes the JSON envelope
  uint8_t nonce[12]; esp_fill_random(nonce, 12);
  char aad[48]; int al = snprintf(aad, sizeof(aad), "%s|%lu", DEVICE_ID, (unsigned long)seq);
  uint8_t ct[256], tag[16]; mbedtls_gcm_context g; mbedtls_gcm_init(&g);
  mbedtls_gcm_setkey(&g, MBEDTLS_CIPHER_ID_AES, key, 256);
  mbedtls_gcm_crypt_and_tag(&g, MBEDTLS_GCM_ENCRYPT, len, nonce, 12, (uint8_t*)aad, al, (uint8_t*)plain, ct, 16, tag);
  mbedtls_gcm_free(&g);
  memcpy(ct + len, tag, 16);                                            // ciphertext || tag (same layout as Python AESGCM)
  size_t n1, n2; char b64n[24], b64c[400];
  mbedtls_base64_encode((uint8_t*)b64n, sizeof(b64n), &n1, nonce, 12);
  mbedtls_base64_encode((uint8_t*)b64c, sizeof(b64c), &n2, ct, len + 16);
  b64n[n1] = 0; b64c[n2] = 0;
  snprintf(out, outLen, "{\"d\":\"%s\",\"s\":%lu,\"n\":\"%s\",\"c\":\"%s\"}", DEVICE_ID, (unsigned long)seq, b64n, b64c);
  return true;
}

void onCmd(char *topic, byte *payload, unsigned int len) {              // authenticated actuator command
  StaticJsonDocument<512> env; if (deserializeJson(env, payload, len)) return;
  if (strcmp(env["d"] | "", "cmd:" DEVICE_ID) != 0) return;
  uint32_t s = env["s"]; if (s <= cmdSeq) return;                       // replay protection
  uint8_t nonce[12], ct[128]; size_t nl, cl;
  mbedtls_base64_decode(nonce, 12, &nl, (const uint8_t*)(const char*)env["n"], strlen(env["n"]));
  mbedtls_base64_decode(ct, sizeof(ct), &cl, (const uint8_t*)(const char*)env["c"], strlen(env["c"]));
  if (cl < 17) return; uint8_t pt[112]; char aad[48]; int al = snprintf(aad, sizeof(aad), "cmd:%s|%lu", DEVICE_ID, (unsigned long)s);
  mbedtls_gcm_context g; mbedtls_gcm_init(&g); mbedtls_gcm_setkey(&g, MBEDTLS_CIPHER_ID_AES, key, 256);
  int rc = mbedtls_gcm_auth_decrypt(&g, cl - 16, nonce, 12, (uint8_t*)aad, al, ct + cl - 16, 16, ct, pt); mbedtls_gcm_free(&g);
  if (rc != 0) return;                                                  // forged command -> ignored
  pt[cl - 16] = 0; StaticJsonDocument<64> cmd; if (deserializeJson(cmd, (char*)pt)) return;
  cmdSeq = s; digitalWrite(FAN_PIN, (int)cmd["fan"] ? HIGH : LOW);
}

void connectAll() {
  WiFi.begin(WIFI_SSID, WIFI_PASS); while (WiFi.status() != WL_CONNECTED) delay(300);
  configTime(0, 0, "pool.ntp.org");
  net.setCACert(CA_PEM); net.setCertificate(CLIENT_CRT_PEM); net.setPrivateKey(CLIENT_KEY_PEM);
  mqtt.setServer(BROKER_HOST, 8883); mqtt.setCallback(onCmd);
  while (!mqtt.connected()) { if (!mqtt.connect(DEVICE_ID)) delay(2000); }
  mqtt.subscribe("campus/airq/" DEVICE_ID "/cmd", 1);
}

void setup() {
  Serial.begin(115200); pinMode(PIR_PIN, INPUT); pinMode(FAN_PIN, OUTPUT); dht.begin(); hex2bin(DEVICE_KEY_HEX, key, 32);
  connectAll();
}

void loop() {
  if (!mqtt.connected()) connectAll();
  mqtt.loop();
  static unsigned long lastS = 0; static float gasSum = 0; static int n = 0;
  if (millis() - lastS > 10000) { lastS = millis(); gasSum += mqToPpm(analogRead(MQ_PIN)); n++; if (digitalRead(PIR_PIN)) motionEvents++; } // edge aggregation
  if (millis() - lastRep > PERIOD_MS && n > 0) {
    lastRep = millis(); seq++;
    float occTrue = min(80, motionEvents * 4);                          // crude people-estimate from PIR activity (calibrate!)
    int occDp = max(0, (int)lroundf(occTrue + laplace(1.0f / EPSILON))); // raw occupancy never leaves the device
    char plain[160];
    int len = snprintf(plain, sizeof(plain), "{\"ts\":%lu,\"temp_c\":%.2f,\"hum_pct\":%.1f,\"gas_ppm\":%.1f,\"occ_dp\":%d,\"fan\":%d}",
                       (unsigned long)time(nullptr), dht.readTemperature(), dht.readHumidity(), gasSum / n, occDp, digitalRead(FAN_PIN));
    char env[640]; seal(plain, len, env, sizeof(env));
    mqtt.publish("campus/airq/" DEVICE_ID "/data", env);
    gasSum = 0; n = 0; motionEvents = 0;
  }
}
