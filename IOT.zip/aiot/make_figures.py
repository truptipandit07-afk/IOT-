import json, numpy as np, pandas as pd, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
m = json.load(open("results/metrics.json")); F = "results/figures/"
c = m["classifier"]; cm = np.array(c["confusion_matrix"])
fig, ax = plt.subplots(figsize=(4.5, 4)); ax.imshow(cm, cmap="Blues")
for i in range(3):
    for j in range(3): ax.text(j, i, cm[i, j], ha="center", va="center", color="white" if cm[i, j] > cm.max()/2 else "black")
ax.set_xticks(range(3), c["labels"]); ax.set_yticks(range(3), c["labels"]); ax.set_xlabel("Predicted"); ax.set_ylabel("Actual")
ax.set_title("30-min AQI forecast (eps=1)"); plt.tight_layout(); plt.savefig(F + "fig_confusion.png", dpi=150); plt.close()
pu = pd.DataFrame(m["privacy_utility"]); x = [str(e) for e in pu.epsilon]
fig, a1 = plt.subplots(figsize=(6, 3.8)); a1.plot(x, pu.macro_f1, "o-b"); a1.set_ylabel("Macro-F1", color="b"); a1.set_xlabel("epsilon (smaller = more private)")
a2 = a1.twinx(); a2.plot(x, pu.occ_mae_people, "s--r"); a2.set_ylabel("Occupancy error (people)", color="r")
plt.title("Privacy-utility trade-off"); plt.tight_layout(); plt.savefig(F + "fig_privacy_utility.png", dpi=150); plt.close()
te = pd.read_csv("results/test_predictions.csv"); d = te[te.device == "room_A101"].iloc[:2880]
fig, ax = plt.subplots(figsize=(8, 3.6)); ax.plot(d.t_min / 60, d.gas_ppm, lw=.8, label="CO2-eq (ppm)")
f = d[d.fault == 1]; ax.scatter(f.t_min / 60, f.gas_ppm, s=8, c="orange", label="injected fault")
g = d[d.anom_flag == 1]; ax.scatter(g.t_min / 60, g.gas_ppm, s=14, facecolors="none", edgecolors="r", label="detected")
ax.set_xlabel("hours (test period)"); ax.legend(); ax.set_title("Anomaly detection, room_A101"); plt.tight_layout(); plt.savefig(F + "fig_anomaly.png", dpi=150); plt.close()
fi = c["feature_importance"]; fig, ax = plt.subplots(figsize=(5, 3.6)); ax.barh(list(fi)[::-1], list(fi.values())[::-1]); ax.set_title("Feature importance"); plt.tight_layout(); plt.savefig(F + "fig_importance.png", dpi=150)
