"""Streamlit dashboard with role-based access control + audit logging.
  streamlit run dashboard/app.py          (users: viewer/viewer123 , admin/admin123 - CHANGE in production)
viewer: pseudonymised aggregates only.  admin: also alerts, encrypted-archive access, audit log, retention purge."""
import hashlib, hmac, os, sqlite3, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pandas as pd, streamlit as st
from common import config as C
from cloud.db import Store

def h(pw, salt=b"dash-salt"): return hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 200_000).hex()
USERS = {"viewer": (h("viewer123"), "viewer"), "admin": (h("admin123"), "admin")}
st.set_page_config(page_title="Privacy-Aware AIoT Air Quality", layout="wide")
store = Store()

if "role" not in st.session_state:
    st.title("Privacy-Aware AIoT Monitor - sign in")
    u, p = st.text_input("User"), st.text_input("Password", type="password")
    if st.button("Sign in"):
        ok = u in USERS and hmac.compare_digest(USERS[u][0], h(p))
        store.audit(u or "?", "LOGIN_OK" if ok else "LOGIN_FAIL")
        if ok: st.session_state.update(role=USERS[u][1], user=u); st.rerun()
        else: st.error("Invalid credentials")
    st.stop()

role, user = st.session_state.role, st.session_state.user
st.sidebar.write(f"Signed in as **{user}** ({role})")
if st.sidebar.button("Sign out"): st.session_state.clear(); st.rerun()
df = pd.read_sql("SELECT * FROM readings ORDER BY ts", store.db)
st.title("Smart Campus Air Quality - privacy-preserving view")
if df.empty: st.info("No data yet. Start the simulator."); st.stop()
df["time"] = pd.to_datetime(df.ts, unit="s")
c = st.columns(4)
last = df.groupby("pid").tail(1)
c[0].metric("Rooms (pseudonyms)", df.pid.nunique()); c[1].metric("Readings", len(df))
c[2].metric("Rooms rated Poor now", int((last.cur_class == "Poor").sum()))
c[3].metric("Sensor anomalies", int(df.is_anomaly.sum()))
pid = st.selectbox("Room (pseudonym)", sorted(df.pid.unique())); d = df[df.pid == pid].tail(720).set_index("time")
st.subheader("CO2-equivalent (ppm)"); st.line_chart(d[["gas_ppm"]])
a, b = st.columns(2)
a.subheader("Temperature (C)"); a.line_chart(d[["temp_c"]])
b.subheader("Occupancy (eps-DP noisy count)"); b.line_chart(d[["occ_dp"]])
st.subheader("Latest decisions"); st.dataframe(d[["gas_ppm", "cur_class", "pred_class", "is_anomaly", "action", "fan"]].tail(15).iloc[::-1])
if role == "admin":
    st.divider(); st.subheader("Admin: alerts")
    st.dataframe(pd.read_sql("SELECT * FROM alerts ORDER BY ts DESC LIMIT 50", store.db))
    if st.button("Decrypt latest 3 archive records"):
        store.audit(user, "ARCHIVE_READ"); st.json([r for _, r in store.read_archive(3)])
    st.subheader("Audit log"); st.dataframe(pd.read_sql("SELECT datetime(ts,'unixepoch') t, actor, action, detail FROM audit ORDER BY ts DESC LIMIT 30", store.db))
    if st.button(f"Purge data older than {C.RETENTION_DAYS} days"):
        n = store.purge(int(df.ts.max())); store.audit(user, "PURGE", str(n)); st.success(f"{n} rows purged")
