"""One-command end-to-end demo (no broker/hardware needed):
 5 simulated edge nodes -> AES-GCM envelopes -> loopback bus -> cloud pipeline -> ML -> actions -> SQLite.
  python run_demo.py --days 2
"""
import argparse, json, os, shutil
import numpy as np, pandas as pd
from common import config as C
from common.transport import LoopbackTransport
from edge.node import build_fleet
from cloud.service import CloudService
from cloud.db import Store

ap = argparse.ArgumentParser(); ap.add_argument("--days", type=float, default=1)
ap.add_argument("--fresh", action="store_true"); ap.add_argument("--start-hour", type=float, default=8); a = ap.parse_args()
if a.fresh and os.path.exists(C.DB_PATH): os.remove(C.DB_PATH)
bus = LoopbackTransport(); store = Store(); svc = CloudService(bus, store)
fleet = build_fleet(bus, C.DP_EPSILON, seed=21, fault_rate=0.0010)   # different seed from training
truth = {"fault": 0, "detected": 0}
for t in range(int(a.start_hour * 60), int(a.start_hour * 60 + a.days * 1440)):
    for n in fleet: n.tick(t)
print("stats:", dict(svc.stats), "| rejected:", svc.v.rejected)
df = pd.read_sql("SELECT * FROM readings", store.db)
print(df.groupby("pid").agg(rows=("ts", "size"), anomalies=("is_anomaly", "sum"), max_gas=("gas_ppm", "max")))
print("alerts:", store.db.execute("SELECT COUNT(*) FROM alerts").fetchone()[0],
      "| fan-on minutes:", int(df.fan.sum()), "of", len(df))
# privacy check: the analytics DB contains no raw device ids and no true occupancy
assert not any(d in str(df.pid.unique()) for d in C.DEVICES)
print("pseudonyms:", list(df.pid.unique()))
print("archive sample (decrypted with Fernet key):", store.read_archive(1)[0][1])
print("raw blob in DB is ciphertext:", store.db.execute("SELECT blob FROM archive LIMIT 1").fetchone()[0][:30])
