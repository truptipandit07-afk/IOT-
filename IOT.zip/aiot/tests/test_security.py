"""Security & privacy unit tests.  Run: python -m tests.test_security"""
import json, os, tempfile, numpy as np
from common import config as C
from common.security import *
from common.transport import topic_matches
from cloud.db import Store

M = C.MASTER_SECRET
def test_roundtrip():
    k = derive_device_key(M, "room_A101"); v = EnvelopeVerifier(M)
    d, r = v.open(encrypt_reading({"gas_ppm": 512.3}, k, "room_A101", 1)); assert d == "room_A101" and r["gas_ppm"] == 512.3
def test_confidentiality():
    k = derive_device_key(M, "room_A101"); raw = encrypt_reading({"gas_ppm": 512.3}, k, "room_A101", 1)
    assert b"512" not in raw and b"gas_ppm" not in raw
def test_tamper_detected():
    k = derive_device_key(M, "room_A101"); env = json.loads(encrypt_reading({"a": 1}, k, "room_A101", 1))
    ct = bytearray(b64d(env["c"])); ct[0] ^= 1; env["c"] = b64e(bytes(ct))
    try: EnvelopeVerifier(M).open(json.dumps(env).encode()); assert False
    except AuthError: pass
def test_header_binding():          # changing the seq/device in the header invalidates the tag (AAD)
    k = derive_device_key(M, "room_A101"); env = json.loads(encrypt_reading({"a": 1}, k, "room_A101", 5)); env["s"] = 99
    try: EnvelopeVerifier(M).open(json.dumps(env).encode()); assert False
    except AuthError: pass
def test_replay_rejected():
    k = derive_device_key(M, "room_A101"); v = EnvelopeVerifier(M); raw = encrypt_reading({"a": 1}, k, "room_A101", 1)
    v.open(raw)
    try: v.open(raw); assert False
    except ReplayError: pass
def test_wrong_device_key():
    k = derive_device_key(M, "room_A102")                      # attacker holds another device's key
    try: EnvelopeVerifier(M).open(encrypt_reading({"a": 1}, k, "room_A101", 1)); assert False
    except AuthError: pass
def test_key_isolation(): assert derive_device_key(M, "a") != derive_device_key(M, "b")
def test_pseudonym():
    p = pseudonymize("room_A101", C.PSEUDO_SALT); assert p != "room_A101" and p == pseudonymize("room_A101", C.PSEUDO_SALT)
    assert p != pseudonymize("room_A101", b"other-salt")
def test_dp_unbiased_and_scale():
    rng = np.random.default_rng(0); x = np.array([dp_count(30, 1.0, 1.0, rng) for _ in range(20000)])
    assert abs(x.mean() - 30) < 0.1 and 1.1 < x.std() < 1.7        # Laplace(b=1): std = sqrt2 ~ 1.41
    y = np.array([dp_count(30, 0.1, 1.0, rng) for _ in range(20000)]); assert y.std() > 8 * x.std() * 0.8
def test_dp_epsilon_ratio():       # empirical eps-DP check on neighbouring counts 30 vs 31
    rng = np.random.default_rng(1); eps = 1.0
    a = np.array([dp_count(30, eps, 1.0, rng) for _ in range(200000)]); b = np.array([dp_count(31, eps, 1.0, rng) for _ in range(200000)])
    for v in (28, 29, 30, 31, 32, 33):
        pa, pb = (a == v).mean(), (b == v).mean(); assert pa / pb < np.exp(eps) * 1.08 and pb / pa < np.exp(eps) * 1.08
def test_encrypted_archive_and_retention():
    path = tempfile.mktemp(suffix=".db"); s = Store(path); s.archive(1000, {"secret": 42}); s.archive(10**9, {"new": 1})
    blob = s.db.execute("SELECT blob FROM archive WHERE ts=1000").fetchone()[0]; assert b"secret" not in blob
    assert s.purge(now_ts=10**9, days=30) >= 1 and len(s.read_archive(10)) == 1
def test_topic_acl_matching():
    assert topic_matches("campus/airq/+/data", "campus/airq/room_A101/data")
    assert not topic_matches("campus/airq/+/data", "campus/airq/room_A101/cmd")

if __name__ == "__main__":
    n = 0
    for k, f in list(globals().items()):
        if k.startswith("test_"): f(); n += 1; print("PASS", k)
    print(f"{n}/{n} tests passed")
