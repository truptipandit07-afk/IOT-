"""Cloud-side data preprocessing: validation, gap filling, de-noising, feature engineering.
Identical code is used for offline training and for the live stream (no train/serve skew)."""
import numpy as np, pandas as pd

VALID = {"temp_c": (-10, 60), "hum_pct": (0, 100), "gas_ppm": (300, 5000)}
CLS_FEATURES = ["gas_smooth", "gas_mean15", "gas_slope5", "temp_smooth", "hum_pct",
                "occ_dp", "occ_mean5", "occ_mean15", "hour_sin", "hour_cos", "weekend"]
ANOM_FEATURES = ["gas_diff1", "gas_std5", "gas_resid15", "gas_resid60", "temp_diff1", "invalid",
                 "phys_resid", "phys_m10", "phys_m20", "gas_range8"]
WINDOW = 70  # samples of history required by the features


def features_one_device(g: pd.DataFrame) -> pd.DataFrame:
    g = g.sort_values("ts").copy()
    bad = pd.Series(False, index=g.index)
    for c, (lo, hi) in VALID.items():                       # 1) range validation
        m = (g[c] < lo) | (g[c] > hi) | g[c].isna()
        bad |= m; g.loc[m, c] = np.nan
    g["invalid"] = bad.astype(int)
    for c in VALID: g[c] = g[c].ffill(limit=3).bfill(limit=3)  # 2) short-gap imputation
    g["gas_smooth"] = g.gas_ppm.rolling(3, min_periods=1).median()         # 3) spike-robust smoothing
    g["temp_smooth"] = g.temp_c.rolling(3, min_periods=1).mean()
    g["gas_mean15"] = g.gas_smooth.rolling(15, min_periods=1).mean()
    g["gas_slope5"] = ((g.gas_smooth - g.gas_smooth.shift(5)) / 5).fillna(0)
    g["gas_diff1"] = g.gas_ppm.diff().fillna(0)
    g["gas_std5"] = g.gas_ppm.rolling(5, min_periods=2).std().fillna(10)
    g["gas_resid15"] = g.gas_ppm - g.gas_ppm.rolling(15, min_periods=1).median()
    g["gas_resid60"] = g.gas_ppm - g.gas_ppm.rolling(60, min_periods=1).median()
    g["temp_diff1"] = g.temp_c.diff().fillna(0)
    g["occ_mean5"] = g.occ_dp.rolling(5, min_periods=1).mean()              # temporal averaging of DP noise
    g["occ_mean15"] = g.occ_dp.rolling(15, min_periods=1).mean()
    # mass-balance consistency: d(CO2)/dt should match generation - ventilation
    g["phys_resid"] = (g.gas_ppm.diff() - (0.5 * g.occ_mean5 - 0.02 * (g.gas_smooth.shift(1) - 400))).fillna(0)
    g["phys_m10"] = g.phys_resid.rolling(10, min_periods=1).mean()
    g["phys_m20"] = g.phys_resid.rolling(20, min_periods=1).mean()   # CUSUM-like drift evidence
    g["gas_range8"] = (g.gas_ppm.rolling(8, min_periods=2).max() - g.gas_ppm.rolling(8, min_periods=2).min()).fillna(30)
    hour = ((g.ts - g.ts.iloc[0]) // 60 % 1440 + 0) / 60.0
    g["hour_sin"], g["hour_cos"] = np.sin(2 * np.pi * hour / 24), np.cos(2 * np.pi * hour / 24)
    g["weekend"] = (((g.ts - 1_760_000_000) // 86400) % 7 >= 5).astype(int)
    return g


def make_features(df: pd.DataFrame, group="device") -> pd.DataFrame:
    return pd.concat([features_one_device(g) for _, g in df.groupby(group)]).reset_index(drop=True)


def rule_flags(f: pd.DataFrame, phys_thr: float = None) -> pd.Series:
    """Deterministic first line of defence (cheap enough to also run on the MCU):
    invalid range/dropout, flat-lined sensor, impossible jump, and a CUSUM-like
    mass-balance test that exposes slow sensor drift."""
    r = (f.invalid == 1) | (f.gas_std5 < 0.5) | (f.gas_diff1.abs() > 150)
    if phys_thr is not None: r = r | (f.phys_m20 > phys_thr)
    return r.astype(int)
