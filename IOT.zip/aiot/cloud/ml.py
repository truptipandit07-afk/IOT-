"""Model training + evaluation: AQI forecasting (RandomForest) and anomaly detection (IsolationForest).
  python -m cloud.ml        -> trains, evaluates, saves models/ and results/*.json|png
"""
import json, os, joblib
import numpy as np, pandas as pd
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.metrics import (accuracy_score, f1_score, confusion_matrix, precision_recall_fscore_support,
                             roc_auc_score, average_precision_score)
from common import config as C
from common.security import dp_count
from cloud.preprocess import make_features, CLS_FEATURES, ANOM_FEATURES, rule_flags
from edge.simulator import generate_dataset

HORIZON = 30          # predict air-quality class 30 minutes ahead (pre-emptive ventilation)
TRAIN_FRAC = 0.7      # chronological split (no leakage)


def to_class(ppm): return pd.cut(ppm, C.AQI_BINS, labels=C.AQI_LABELS, right=False).astype(str)


def apply_dp(df, eps, seed=0):
    rng = np.random.default_rng(seed)
    out = df.copy(); out["occ_dp"] = [dp_count(o, eps, 1.0, rng) for o in df.occ_true]
    return out


def prepare(df_raw, eps):
    df = make_features(apply_dp(df_raw, eps))
    df["cur_class"] = to_class(df.gas_smooth)
    df["target"] = df.groupby("device")["co2_true"].shift(-HORIZON).pipe(lambda s: to_class(s.fillna(0)))
    df.loc[df.groupby("device")["co2_true"].transform(lambda s: s.shift(-HORIZON).isna()), "target"] = np.nan
    return df.dropna(subset=["target"]).reset_index(drop=True)


def split(df):
    cut = df.t_min.quantile(TRAIN_FRAC)
    return df[df.t_min <= cut], df[df.t_min > cut]


def fit_clf(tr):
    return RandomForestClassifier(n_estimators=80, max_depth=14, min_samples_leaf=3, n_jobs=-1,
                                  class_weight="balanced", random_state=0).fit(tr[CLS_FEATURES], tr.target)


def eval_clf(m, te):
    p = m.predict(te[CLS_FEATURES])
    return {"accuracy": accuracy_score(te.target, p), "macro_f1": f1_score(te.target, p, average="macro")}, p


def anomaly_scores(model, X): return -model.score_samples(X)   # higher = more anomalous


def run(days=14, out="results"):
    os.makedirs(out, exist_ok=True); os.makedirs("models", exist_ok=True)
    raw = generate_dataset(days=days, seed=1); raw.to_csv("data/training_data_labeled.csv", index=False)
    res = {"dataset": {"rows": len(raw), "days": days, "devices": raw.device.nunique(),
                       "fault_rate_pct": round(100 * raw.fault.mean(), 2)}}

    # ---------------- 1) classification at the deployment privacy level (eps=1) --------------
    df = prepare(raw, C.DP_EPSILON); tr, te = split(df)
    clf = fit_clf(tr); m, pred = eval_clf(clf, te)
    base = (te.cur_class == te.target).mean()
    base_f1 = f1_score(te.target, te.cur_class, average="macro")
    labels = C.AQI_LABELS
    res["classifier"] = {"eps": C.DP_EPSILON, **{k: round(v, 4) for k, v in m.items()},
                         "persistence_baseline_accuracy": round(float(base), 4),
                         "persistence_baseline_macro_f1": round(float(base_f1), 4),
                         "confusion_matrix": confusion_matrix(te.target, pred, labels=labels).tolist(),
                         "labels": labels, "train_rows": len(tr), "test_rows": len(te),
                         "feature_importance": dict(sorted(zip(CLS_FEATURES, map(lambda x: round(float(x), 4),
                                                    clf.feature_importances_)), key=lambda kv: -kv[1]))}
    joblib.dump(clf, "models/aqi_forecaster.joblib")

    # ---------------- 2) privacy-utility trade-off -----------------------------------------
    sweep = []
    for eps in [0.1, 0.25, 0.5, 1.0, 2.0, 5.0, float("inf")]:
        d = prepare(raw, eps); a, b = split(d); mm, _ = eval_clf(fit_clf(a), b)
        true_occ_err = float(np.mean(np.abs(d.occ_dp - d.occ_true)))
        sweep.append({"epsilon": "inf" if np.isinf(eps) else eps, "accuracy": round(mm["accuracy"], 4),
                      "macro_f1": round(mm["macro_f1"], 4), "occ_mae_people": round(true_occ_err, 2)})
    res["privacy_utility"] = sweep

    # ---------------- 3) anomaly detection (hybrid: rules + Isolation Forest) ----------------
    # IF is fitted on a fault-free commissioning window (no labels needed in the field).
    Xn = tr[tr.fault == 0][ANOM_FEATURES]
    iso = IsolationForest(n_estimators=100, random_state=0, n_jobs=-1).fit(Xn)
    thr = float(np.quantile(anomaly_scores(iso, Xn), 0.999))
    phys_thr = float(np.quantile(tr[tr.fault == 0].phys_m20, 0.9995))
    sc = anomaly_scores(iso, te[ANOM_FEATURES]); rule = rule_flags(te, phys_thr).values
    ml_flag = (sc > thr).astype(int); yhat = ((ml_flag == 1) | (rule == 1)).astype(int); y = te.fault.values
    prf = lambda yh: [round(float(v), 4) for v in precision_recall_fscore_support(y, yh, average="binary", zero_division=0)[:3]]
    z = np.abs(te.gas_diff1 - tr.gas_diff1.mean()) / tr.gas_diff1.std(); zhat = (z > 3).astype(int).values
    t2 = te.reset_index(drop=True).assign(flag=yhat)
    t2["ev"] = (t2.fault.diff().fillna(0) == 1).cumsum() * t2.fault
    names = {1: "spike", 2: "stuck", 3: "drift", 4: "dropout"}
    evs = t2[t2.fault == 1].groupby("ev").apply(lambda g: pd.Series({
        "type": names[int(g.fault_type.iloc[0])], "hit": int(g.flag.max()),
        "delay_min": int(np.argmax(g.flag.values)) if g.flag.max() else np.nan}), include_groups=False)
    per_type = {t: {"events": int(len(g)), "detected": int(g.hit.sum()),
                    "median_delay_min": None if g.delay_min.dropna().empty else float(g.delay_min.median())}
                for t, g in evs.groupby("type")}
    normal_days = (te.fault == 0).sum() / 1440 / te.device.nunique()
    res["anomaly"] = {"hybrid": dict(zip(["precision", "recall", "f1"], prf(yhat))),
                      "isolation_forest_only": dict(zip(["precision", "recall", "f1"], prf(ml_flag))),
                      "rules_only": dict(zip(["precision", "recall", "f1"], prf(rule))),
                      "zscore_baseline": dict(zip(["precision", "recall", "f1"], prf(zhat))),
                      "roc_auc_if": round(roc_auc_score(y, sc), 4),
                      "event_recall": round(float(evs.hit.mean()), 4), "events": int(len(evs)),
                      "per_fault_type": per_type,
                      "false_alarms_per_device_day": round(float(yhat[y == 0].sum() / normal_days / te.device.nunique()), 2),
                      "fault_rate_test_pct": round(100 * float(y.mean()), 2)}
    joblib.dump({"model": iso, "threshold": thr, "phys_thr": phys_thr}, "models/anomaly_detector.joblib")
    json.dump(res, open(f"{out}/metrics.json", "w"), indent=2)
    te.assign(pred=pred, anom_score=sc, anom_flag=yhat).to_csv(f"{out}/test_predictions.csv", index=False)
    return res, te, pred, sc, thr


if __name__ == "__main__":
    r, *_ = run()
    print(json.dumps(r, indent=2))
