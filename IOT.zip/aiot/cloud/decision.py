"""Intelligent decision-making: turns ML outputs into safe actuator actions."""
from common import config as C

HOLD_ON_BELOW_PPM = 700   # hysteresis: switch fan off only when air is clearly good


def decide(cur_class, pred_class, is_anomaly, gas_smooth, fan_on):
    """Returns (action, desired_fan_state). Never actuates on data flagged as faulty."""
    if is_anomaly:
        return "ALERT_SENSOR_ANOMALY", fan_on
    if pred_class == "Poor" or cur_class == "Poor":
        return ("FAN_ON_PREVENTIVE" if not fan_on else "KEEP_FAN_ON"), True
    if pred_class == "Moderate" and cur_class == "Moderate" and not fan_on:
        return "NOTIFY_MODERATE", fan_on
    if fan_on and gas_smooth < HOLD_ON_BELOW_PPM and pred_class == "Good":
        return "FAN_OFF", False
    return "NOOP", fan_on
