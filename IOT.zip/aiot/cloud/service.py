"""Cloud service: authenticate -> decrypt -> preprocess -> ML -> decide -> store -> actuate.
  python -m cloud.service            # real mutual-TLS MQTT (needs broker + certs)
"""
import collections, json, os, threading, time
import joblib, numpy as np, pandas as pd
from common import config as C
from common.security import (EnvelopeVerifier, AuthError, ReplayError, pseudonymize,
                            derive_device_key, encrypt_reading)
from cloud.preprocess import features_one_device, CLS_FEATURES, ANOM_FEATURES, rule_flags, WINDOW
from cloud.decision import decide
from cloud.db import Store


class CloudService:
    def __init__(self, transport, store=None, models_dir="models"):
        self.t, self.store = transport, store or Store()
        self.v = EnvelopeVerifier(C.MASTER_SECRET)
        self.buf = collections.defaultdict(lambda: collections.deque(maxlen=WINDOW))
        self.fan, self.cmd_seq = collections.defaultdict(bool), collections.defaultdict(int)
        self.stats = collections.Counter(); self.lock = threading.Lock()
        self.clf = self.iso = None; self.latest_ts = 0
        try:
            self.clf = joblib.load(f"{models_dir}/aqi_forecaster.joblib")
            b = joblib.load(f"{models_dir}/anomaly_detector.joblib")
            self.iso, self.thr, self.phys_thr = b["model"], b["threshold"], b["phys_thr"]
            self.clf.n_jobs = 1; self.iso.n_jobs = 1      # single-row inference: threading only adds overhead
        except FileNotFoundError:
            print("[cloud] models not found - run `python -m cloud.ml` first")
        transport.subscribe(C.DATA_FILTER, self.on_message)

    def on_message(self, topic, payload):
        with self.lock:
            try:
                dev, r = self.v.open(payload)
            except (AuthError, ReplayError) as e:
                self.stats["rejected"] += 1; self.store.audit("cloud", "REJECT_FRAME", str(e)); return
            self.stats["accepted"] += 1; self.latest_ts = max(self.latest_ts, r["ts"])
            pid = pseudonymize(dev, C.PSEUDO_SALT)                  # real id never stored in analytics
            self.store.archive(r["ts"], {"pid": pid, **r})        # encrypted at rest
            self.buf[dev].append(r)
            f = features_one_device(pd.DataFrame(self.buf[dev])).iloc[[-1]]
            score, is_anom, cur, pred = 0.0, 0, "n/a", "n/a"
            if self.iso is not None:
                score = float(-self.iso.score_samples(f[ANOM_FEATURES])[0])
                warm = len(self.buf[dev]) >= 20            # features need history; suppress flags during warm-up
                is_anom = int(warm and (score > self.thr or rule_flags(f, self.phys_thr).iloc[0] == 1))
                cur = str(pd.cut([float(f.gas_smooth.iloc[0])], C.AQI_BINS, labels=C.AQI_LABELS, right=False)[0])
                pred = str(self.clf.predict(f[CLS_FEATURES])[0])
            action, fan = decide(cur, pred, is_anom, float(f.gas_smooth.iloc[0]), self.fan[dev])
            if is_anom: self.store.add_alert(r["ts"], pid, "SENSOR_ANOMALY", f"score={score:.2f}")
            if fan != self.fan[dev]: self._command(dev, fan)
            self.fan[dev] = fan
            self.store.add_reading({"pid": pid, "ts": r["ts"], "temp_c": r["temp_c"], "hum_pct": r["hum_pct"],
                                    "gas_ppm": r["gas_ppm"], "occ_dp": r["occ_dp"], "fan": r["fan"],
                                    "anomaly_score": score, "is_anomaly": is_anom, "pred_class": pred,
                                    "cur_class": cur, "action": action})
            self.stats["anomalies"] += is_anom; self.stats["actions:" + action] += 1

    def _command(self, dev, fan_on):
        self.cmd_seq[dev] += 1
        key = derive_device_key(C.MASTER_SECRET, dev)
        self.t.publish(C.cmd_topic(dev), encrypt_reading({"fan": int(fan_on)}, key, "cmd:" + dev, self.cmd_seq[dev]))
        self.stats["commands"] += 1


def main():
    from common.transport import MqttTransport
    tr = MqttTransport("cloud"); svc = CloudService(tr); tr.start()
    print("[cloud] listening on", C.DATA_FILTER)
    try:
        while True:
            time.sleep(10); print("[cloud]", dict(svc.stats), svc.v.rejected)
            svc.store.purge(svc.latest_ts)   # retention is relative to the newest data timestamp
    except KeyboardInterrupt: tr.stop()


if __name__ == "__main__":
    main()
