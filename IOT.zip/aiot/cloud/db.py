"""Storage: pseudonymised analytics table + Fernet-encrypted archive + audit log + retention."""
import os, sqlite3, threading, time, json
from cryptography.fernet import Fernet
from common import config as C


def _archive_key():
    if C.ARCHIVE_KEY: return C.ARCHIVE_KEY.encode()
    p = "data/archive.key"; os.makedirs("data", exist_ok=True)
    if not os.path.exists(p):
        with open(p, "wb") as f: f.write(Fernet.generate_key())
        os.chmod(p, 0o600)
    return open(p, "rb").read()


class Store:
    def __init__(self, path=C.DB_PATH):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        self.db = sqlite3.connect(path, check_same_thread=False); self.lock = threading.Lock()
        self.db.execute("PRAGMA journal_mode=WAL"); self.db.execute("PRAGMA synchronous=NORMAL")
        self.fernet = Fernet(_archive_key())
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS readings(pid TEXT, ts INT, temp_c REAL, hum_pct REAL, gas_ppm REAL,
            occ_dp INT, fan INT, anomaly_score REAL, is_anomaly INT, pred_class TEXT, cur_class TEXT, action TEXT);
        CREATE TABLE IF NOT EXISTS alerts(ts INT, pid TEXT, kind TEXT, detail TEXT);
        CREATE TABLE IF NOT EXISTS archive(ts INT, blob BLOB);
        CREATE TABLE IF NOT EXISTS audit(ts REAL, actor TEXT, action TEXT, detail TEXT);
        CREATE INDEX IF NOT EXISTS ix_r ON readings(pid, ts);""")

    def add_reading(self, r: dict):
        with self.lock:
            self.db.execute("INSERT INTO readings VALUES(:pid,:ts,:temp_c,:hum_pct,:gas_ppm,:occ_dp,:fan,"
                            ":anomaly_score,:is_anomaly,:pred_class,:cur_class,:action)", r)
            self.db.commit()

    def add_alert(self, ts, pid, kind, detail):
        with self.lock:
            self.db.execute("INSERT INTO alerts VALUES(?,?,?,?)", (ts, pid, kind, detail)); self.db.commit()

    def archive(self, ts, raw: dict):          # encryption at rest
        with self.lock:
            self.db.execute("INSERT INTO archive VALUES(?,?)", (ts, self.fernet.encrypt(json.dumps(raw).encode())))
            self.db.commit()

    def read_archive(self, limit=5):
        rows = self.db.execute("SELECT ts, blob FROM archive ORDER BY ts DESC LIMIT ?", (limit,)).fetchall()
        return [(t, json.loads(self.fernet.decrypt(b))) for t, b in rows]

    def audit(self, actor, action, detail=""):
        with self.lock:
            self.db.execute("INSERT INTO audit VALUES(?,?,?,?)", (time.time(), actor, action, detail)); self.db.commit()

    def purge(self, now_ts, days=C.RETENTION_DAYS):   # retention / storage limitation
        cutoff = now_ts - days * 86400
        with self.lock:
            n = 0
            for t in ("readings", "alerts", "archive"):
                n += self.db.execute(f"DELETE FROM {t} WHERE ts < ?", (cutoff,)).rowcount
            self.db.commit()
        return n
