#!/usr/bin/env bash
# Private CA + broker cert + one client cert per identity (CN = identity => used as MQTT username/ACL key).
set -euo pipefail
D=${1:-certs}; mkdir -p "$D"; cd "$D"
IDS="cloud room_A101 room_A102 room_B201 lab_C301 hall_D001 intruder"
openssl genrsa -out ca.key 4096 2>/dev/null
openssl req -x509 -new -nodes -key ca.key -sha256 -days 825 -subj "/CN=AIoT-Demo-CA" -out ca.crt
# broker (server) certificate with SAN so hostname verification passes
openssl genrsa -out server.key 2048 2>/dev/null
openssl req -new -key server.key -subj "/CN=localhost" -out server.csr
printf "subjectAltName=DNS:localhost,IP:127.0.0.1\nextendedKeyUsage=serverAuth\n" > srv.ext
openssl x509 -req -in server.csr -CA ca.crt -CAkey ca.key -CAcreateserial -out server.crt -days 825 -sha256 -extfile srv.ext 2>/dev/null
for id in $IDS; do
  openssl genrsa -out $id.key 2048 2>/dev/null
  openssl req -new -key $id.key -subj "/CN=$id" -out $id.csr
  printf "extendedKeyUsage=clientAuth\n" > cli.ext
  openssl x509 -req -in $id.csr -CA ca.crt -CAkey ca.key -CAcreateserial -out $id.crt -days 825 -sha256 -extfile cli.ext 2>/dev/null
done
# 'intruder' has a VALID cert but no ACL rights -> used to demonstrate topic-level authorisation
rm -f *.csr *.ext *.srl; chmod 600 *.key
echo "certs written to $D"
