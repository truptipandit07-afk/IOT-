"""Prints the per-device AES-256 key (hex) to burn into the ESP32 secrets.h for a device id."""
import sys
from common import config as C
from common.security import derive_device_key
dev = sys.argv[1]; k = derive_device_key(C.MASTER_SECRET, dev)
print(f'#define DEVICE_ID "{dev}"\n#define DEVICE_KEY_HEX "{k.hex()}"')
