"""Active security verification against the live mutual-TLS broker (run scripts/run_tls_demo.sh pieces first)."""
import json, socket, ssl, sys, time
import paho.mqtt.client as mqtt
from common import config as C

res = []
def check(name, ok): res.append((name, ok)); print(("PASS " if ok else "FAIL ") + name)

# 1) plaintext MQTT must not work on the TLS port
s = socket.create_connection((C.BROKER_HOST, C.BROKER_PORT), timeout=3)
s.sendall(bytes([0x10, 0x0c, 0, 4]) + b"MQTT" + bytes([4, 2, 0, 60, 0, 0])); s.settimeout(3)
try: reply = s.recv(16)
except Exception: reply = b""
check("plaintext MQTT connection is refused (no CONNACK)", not reply.startswith(b"\x20"))

# 2) TLS without client certificate is rejected
ctx = ssl.create_default_context(cafile=C.CA_CERT)
try:
    with socket.create_connection((C.BROKER_HOST, C.BROKER_PORT), timeout=3) as r, ctx.wrap_socket(r, server_hostname="localhost") as t:
        t.sendall(bytes([0x10, 0x0c, 0, 4]) + b"MQTT" + bytes([4, 2, 0, 60, 0, 0])); t.settimeout(3)
        got = t.recv(16); ok = not got.startswith(b"\x20")
except (ssl.SSLError, ConnectionError, OSError): ok = True
check("TLS handshake without client certificate is rejected", ok)

# 3) TLS 1.0/1.1 rejected
try:
    c2 = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT); c2.load_verify_locations(C.CA_CERT); c2.maximum_version = ssl.TLSVersion.TLSv1_1
    c2.minimum_version = ssl.TLSVersion.MINIMUM_SUPPORTED
    with socket.create_connection((C.BROKER_HOST, C.BROKER_PORT), timeout=3) as r: c2.wrap_socket(r, server_hostname="localhost"); ok = False
except Exception: ok = True
check("legacy TLS (<=1.1) is rejected", ok)

def client(cid):
    c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=cid)
    c.tls_set(ca_certs=C.CA_CERT, certfile=f"{C.CERT_DIR}/{cid}.crt", keyfile=f"{C.CERT_DIR}/{cid}.key")
    return c
got = []
cloud = client("cloud"); cloud.on_message = lambda c, u, m: got.append((m.topic, m.payload))
cloud.on_connect = lambda c, u, f, rc, p=None: c.subscribe("campus/airq/+/data", 1)
cloud.connect(C.BROKER_HOST, C.BROKER_PORT); cloud.loop_start(); time.sleep(1)

dev = client("room_A101"); dev.connect(C.BROKER_HOST, C.BROKER_PORT); dev.loop_start(); time.sleep(0.5)
dev.publish("campus/airq/room_A101/data", b"legit", 1); time.sleep(0.5)
dev.publish("campus/airq/room_A102/data", b"spoofed-as-other-room", 1); time.sleep(0.5)   # ACL violation
intr = client("intruder"); intr.connect(C.BROKER_HOST, C.BROKER_PORT); intr.loop_start(); time.sleep(0.5)
intr.publish("campus/airq/room_A101/data", b"intruder-injection", 1); time.sleep(0.8)
payloads = [p for _, p in got]
check("device can publish to its own topic", b"legit" in payloads)
check("device cannot publish to another device's topic (ACL)", b"spoofed-as-other-room" not in payloads)
check("valid-cert intruder without ACL grants cannot inject data", b"intruder-injection" not in payloads)

cmd_seen = []
dev.on_message = lambda c, u, m: cmd_seen.append(m.payload); dev.subscribe("campus/airq/room_A102/cmd", 1); time.sleep(0.5)
cloud.publish("campus/airq/room_A102/cmd", b"x", 1); time.sleep(0.5)
check("device cannot subscribe to another device's command topic", not cmd_seen)
for c in (cloud, dev, intr): c.loop_stop(); c.disconnect()
print(f"{sum(o for _, o in res)}/{len(res)} checks passed"); sys.exit(0 if all(o for _, o in res) else 1)
