#!/usr/bin/env bash
# Real broker demo: mutual-TLS Mosquitto + cloud service + simulated edge fleet.
set -e
[ -d certs ] && [ -f certs/ca.crt ] || scripts/gen_certs.sh certs
mosquitto -c mosquitto/mosquitto.conf & BROKER=$!
sleep 1
python -m cloud.service & CLOUD=$!
sleep 2
python -m edge.simulator --mode mqtt --days ${1:-0.25} --interval 0.02
sleep 2; kill $CLOUD $BROKER
