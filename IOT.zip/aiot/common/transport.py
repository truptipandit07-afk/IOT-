"""Transport abstraction: the same edge/cloud code runs over a real
mutual-TLS MQTT broker or an in-process loopback bus (offline demo/tests)."""
import threading
from common import config as C


def topic_matches(filt: str, topic: str) -> bool:
    f, t = filt.split("/"), topic.split("/")
    for i, p in enumerate(f):
        if p == "#": return True
        if i >= len(t): return False
        if p != "+" and p != t[i]: return False
    return len(f) == len(t)


class LoopbackTransport:
    """Shared in-process bus. Create one instance and hand it to all parties."""
    def __init__(self): self.subs, self.lock = [], threading.Lock()
    def subscribe(self, filt, cb): self.subs.append((filt, cb))
    def publish(self, topic, payload: bytes):
        for filt, cb in list(self.subs):
            if topic_matches(filt, topic): cb(topic, payload)
    def start(self): pass
    def stop(self): pass


class MqttTransport:
    """paho-mqtt client using TLS 1.2+ with mutual (client-certificate) authentication."""
    def __init__(self, client_id: str, host=None, port=None):
        import ssl, paho.mqtt.client as mqtt
        self.c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=client_id)
        self.c.tls_set(ca_certs=C.CA_CERT, certfile=f"{C.CERT_DIR}/{client_id}.crt",
                       keyfile=f"{C.CERT_DIR}/{client_id}.key", tls_version=ssl.PROTOCOL_TLS_CLIENT)
        self.c.tls_insecure_set(False)   # verify broker hostname against CA
        self.host, self.port, self._subs = host or C.BROKER_HOST, port or C.BROKER_PORT, []
        self.c.on_connect = self._on_connect
        self.c.on_message = lambda cl, ud, m: self._dispatch(m.topic, m.payload)

    def _on_connect(self, cl, ud, flags, rc, props=None):
        for f, _ in self._subs: cl.subscribe(f, qos=1)

    def _dispatch(self, topic, payload):
        for f, cb in self._subs:
            if topic_matches(f, topic): cb(topic, payload)

    def subscribe(self, filt, cb): self._subs.append((filt, cb))
    def publish(self, topic, payload: bytes): self.c.publish(topic, payload, qos=1)
    def start(self): self.c.connect(self.host, self.port, keepalive=30); self.c.loop_start()
    def stop(self): self.c.loop_stop(); self.c.disconnect()
