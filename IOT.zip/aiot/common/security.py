"""Security & privacy primitives: key derivation, AES-256-GCM envelopes,
replay protection, pseudonymisation and differential-privacy noise."""
import base64, hashlib, hmac, json, os
import numpy as np
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

b64e = lambda b: base64.b64encode(b).decode()
b64d = lambda s: base64.b64decode(s.encode())


def derive_device_key(master: bytes, device_id: str) -> bytes:
    """Per-device 256-bit key via HKDF-SHA256 (compromise of one device != all)."""
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=None,
                info=b"aiot-device-key|" + device_id.encode()).derive(master)


def encrypt_reading(reading: dict, key: bytes, device_id: str, seq: int) -> bytes:
    nonce = os.urandom(12)
    aad = f"{device_id}|{seq}".encode()          # binds ciphertext to device + counter
    ct = AESGCM(key).encrypt(nonce, json.dumps(reading, separators=(",", ":")).encode(), aad)
    return json.dumps({"d": device_id, "s": seq, "n": b64e(nonce), "c": b64e(ct)}).encode()


class ReplayError(Exception): pass
class AuthError(Exception): pass


class EnvelopeVerifier:
    """Decrypts + authenticates envelopes and rejects replayed / reordered frames."""
    def __init__(self, master: bytes):
        self.master, self.last_seq = master, {}
        self.rejected = {"auth": 0, "replay": 0, "malformed": 0}

    def open(self, raw: bytes) -> tuple[str, dict]:
        try:
            env = json.loads(raw); dev, seq = env["d"], int(env["s"])
            nonce, ct = b64d(env["n"]), b64d(env["c"])
        except Exception:
            self.rejected["malformed"] += 1; raise AuthError("malformed envelope")
        key = derive_device_key(self.master, dev)
        try:
            pt = AESGCM(key).decrypt(nonce, ct, f"{dev}|{seq}".encode())
        except InvalidTag:
            self.rejected["auth"] += 1; raise AuthError("tag mismatch (tampered / wrong key)")
        if seq <= self.last_seq.get(dev, -1):
            self.rejected["replay"] += 1; raise ReplayError(f"replayed seq {seq} from {dev}")
        self.last_seq[dev] = seq
        return dev, json.loads(pt)


def pseudonymize(device_id: str, salt: bytes) -> str:
    """Keyed one-way pseudonym; stored data never contains the real device/room id."""
    return hmac.new(salt, device_id.encode(), hashlib.sha256).hexdigest()[:12]


def laplace_noise(scale: float, rng=None) -> float:
    rng = rng or np.random.default_rng()
    return float(rng.laplace(0.0, scale))


def dp_count(true_count: float, epsilon: float, sensitivity: float = 1.0, rng=None) -> int:
    """epsilon-DP release of an occupancy count (Laplace mechanism, post-processed to int>=0)."""
    if epsilon is None or np.isinf(epsilon):
        return int(round(true_count))
    return max(0, int(round(true_count + laplace_noise(sensitivity / epsilon, rng))))


class DeviceVerifier:
    """Used by an edge device to authenticate cloud->device commands with its own key."""
    def __init__(self, key: bytes, expected_id: str):
        self.key, self.expected_id, self.last_seq = key, expected_id, -1

    def open(self, raw: bytes) -> dict:
        try:
            env = json.loads(raw)
            if env["d"] != self.expected_id: raise AuthError("wrong sender id")
            seq = int(env["s"])
            pt = AESGCM(self.key).decrypt(b64d(env["n"]), b64d(env["c"]), f"{env['d']}|{seq}".encode())
        except (InvalidTag, KeyError, ValueError) as e:
            raise AuthError(f"bad command: {e!r}")
        if seq <= self.last_seq: raise ReplayError("replayed command")
        self.last_seq = seq
        return json.loads(pt)
