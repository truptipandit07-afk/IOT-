"""Central configuration (override with environment variables)."""
import os

BROKER_HOST = os.getenv("BROKER_HOST", "localhost")
BROKER_PORT = int(os.getenv("BROKER_PORT", "8883"))
CERT_DIR = os.getenv("CERT_DIR", "certs")
CA_CERT = f"{CERT_DIR}/ca.crt"

TOPIC_ROOT = "campus/airq"
def data_topic(device_id): return f"{TOPIC_ROOT}/{device_id}/data"
def cmd_topic(device_id): return f"{TOPIC_ROOT}/{device_id}/cmd"
DATA_FILTER = f"{TOPIC_ROOT}/+/data"

# Secrets: in production load from a secrets manager / HSM, never hard-code.
MASTER_SECRET = os.getenv("MASTER_SECRET", "dev-only-master-secret-change-me").encode()
PSEUDO_SALT = os.getenv("PSEUDO_SALT", "dev-only-pseudonym-salt").encode()
ARCHIVE_KEY = os.getenv("ARCHIVE_KEY")  # Fernet key; auto-generated into data/archive.key if absent

DB_PATH = os.getenv("DB_PATH", "data/iot.db")
RETENTION_DAYS = int(os.getenv("RETENTION_DAYS", "30"))

DP_EPSILON = float(os.getenv("DP_EPSILON", "1.0"))   # local DP budget per occupancy report
OCC_SENSITIVITY = 1.0                                # one person changes the count by 1

# Thresholds on CO2-equivalent ppm (MQ-135 calibrated)
AQI_BINS = [0, 800, 1200, 10**6]
AQI_LABELS = ["Good", "Moderate", "Poor"]
DEVICES = ["room_A101", "room_A102", "room_B201", "lab_C301", "hall_D001"]
